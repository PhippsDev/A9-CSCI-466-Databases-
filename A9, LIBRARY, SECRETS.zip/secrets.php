<?php

$username = 'z1843045';
$password = '2000Feb14';

?>