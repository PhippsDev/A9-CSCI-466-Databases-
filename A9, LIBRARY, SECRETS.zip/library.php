<?php

    function draw_table($rows)
    {
        if(empty($rows))
        {
            echo "<p>No results found.</p>";
        }
        else
        {
        echo "<table border=3 cellspacing=3>";
        echo "<tr>";
        
        foreach($rows[0] as $key => $item)
        {
            echo "<th>$key</th>";
        }}
        echo "</tr>";
        foreach($rows as $row)
        {
            echo "<tr>";
            foreach($row as $key => $item)
            {
                echo "<td>$item</td>";
            }
            echo "</tr>";
        }
        echo "</table\n\n>";
    }
?>