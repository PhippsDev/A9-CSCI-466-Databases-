<?php
declare(strict_types = 1);
ini_set('display_errors', '1');
ini_set('displays_startup_errors', '1');
error_reporting(E_ALL);
?>
<html>
    <head>
        <title>Assignment 9</title>
    </head>
    <body>
        <h1>assignment 9</h1>
<?php

include('secrets.php');
include('library.php');
$dsn = "mysql:host=courses;dbname=z1843045";
    try
    {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOexception $e)
    {
        die( "Connection to database failed: " . $e->getMessage());

    }
?>
            <h3>GET</h3>

            <pre><?php print_r($_GET); ?></pre>

            <h3>POST</h3>

            <pre><?php print_r($_POST); ?></pre>

            <h3>1. Suppliers</h3>

<?php
$sql = 'SELECT * FROM Suppliers;';
try
{
    $rs = $pdo->query($sql);
    $rows = ($rs->fetchAll(PDO::FETCH_ASSOC));
    draw_table($rows);
}
catch(PDOException $e)
{
    echo "Couldn't retrieve the list of Suppliers. Query failed with PDO exception with message: " . $e->getMessage();
}
?>
        <h3>2. Parts</h3>
<?php
$sql = 'SELECT * FROM Parts;';
try
{
    $rs = $pdo->query($sql);
    $rows = ($rs->fetchAll(PDO::FETCH_ASSOC));
    draw_table($rows);
}
catch(PDOException $e)
{
    echo "Couldn't retrieve the list of Parts. Query failed with PDO exception with message: " . $e->getMessage();
}
?>

        <h3>3. Part Information</h3>
        <form>
            <label for="Parts">Choose a part:</label>
            <select name="P" id="Parts">
                <option value="P1">Red Nut</option>
                <option value="P2">Green Bolt</option>
                <option value="P3">Blue Screw</option>
                <option value="P4">Red Screw</option>
                <option value="P5">Blue Cam</option>
                <option value="P6">Red Cog</option>
            </select>
            <br><br>
            <input type="submit" value="Submit">
        </form>
    
<?php
if(isset($_GET['P']))
{
    $sql = 'SELECT * FROM SuppliedParts JOIN Suppliers USING (Supplier) JOIN Parts USING (Part) WHERE Part = ?;';
    try
    { // if something goes wrong, an exception is thrown
        //query to retrieve data from SP and join with Suppliers and Parts. And function to draw table
        $statement = $pdo->prepare($sql);
        $result = $statement->execute(array($_GET['P']));
        if($result)
        {
            $rows = ($statement->fetchAll(PDO::FETCH_ASSOC));
            draw_table($rows);
        }
        else {
            echo "Couldn't retrieve list of Parts. Query failed for unknown reason.";
        }
    }
    catch(PDOException $e)
    {
        echo "Couldn't retrieve list of Parts. Query failed due to PDO Exception with message: " . $e->getMessage();
    }
}
?>

<h3>4. Supplier Information</h3>
        <form>
            <label for="Suppliers">Choose a Supplier:</label>
            <select name="S" id="Supplier">
                <option value="S1">Smith</option>
                <option value="S2">Jones</option>
                <option value="S3">Blake</option>
                <option value="S4">Clark</option>
                <option value="S5">Adams</option>
            </select>
            <br><br>
            <input type="submit" value="Submit">
        </form>
    
<?php

if(isset($_GET['S']))
{
    $sql = 'SELECT * FROM SuppliedParts JOIN Suppliers USING (Supplier) JOIN Parts USING (Part) WHERE Supplier = ?;';
    try
    { // if something goes wrong, an exception is thrown
        //query to retrieve data from SP and join with Suppliers and Parts. And function to draw table
        $statement = $pdo->prepare($sql);
        $result = $statement->execute(array($_GET['S']));
        if($result)
        {
            $rows = ($statement->fetchAll(PDO::FETCH_ASSOC));
            draw_table($rows);
        }
        else {
            echo "Couldn't retrieve list of Suppliers. Query failed for unknown reason.";
        }
    }
    catch(PDOException $e)
    {
        echo "Couldn't retrieve list of Suppliers. Query failed due to PDO Exception with message: " . $e->getMessage();
    }
}
?>

    <h3>5. Purchase Parts from Supplier</h3>
        <form method="POST">
            <label for="Parts">Please enter desired Part:</label>
            <input type="text" id="Parts" name="P" placeholder="P1">
            <br><br>
            <label for="Suppliers">Please enter desired Supplier:</label>
            <input type="text" id="Suppliers" name="S" placeholder="S1">
            <br><br>
            <label for="QTY">Please enter desired QTY of Parts:</label>
            <input type="text" id="QTY" name="QTY" placeholder="25">
            <br><br>
            <input type="submit" value="Submit">
        </form>
<?php
if(isset($_POST['Submit']))
{
    $sql = "UPDATE SuppliedParts SET QTY = QTY - ? WHERE Supplier = ? AND Part = ?";
    try
    {
        $statement = $pdo->prepare($sql);
        $result = $statement->execute([$_POST['QTY'], $_SESSION['S'], $_SESSION['P']]);
        if($result)
        {
            echo "Purchase has been Completed, enjoy!";
        }
        else
        {
            echo "Purchase has been declined due to Card Issue, or Insufficient Stock";
        }
        
    }
    catch(PDOException $e)
    {
        echo "Couldn't receive the list of Suppliers. Query failed due to PDO Exception with message: " . $e->getMessage();
    }
}
?>


    <h3>6. Adding a Part to Database</h3>
    <form method="POST">
            <label for="Part">Please enter desired Part to be added:</label>
            <input type="text" id="Part" name="Part" placeholder="P1">
            <br>
            <label for="PName">Please enter desired type of Part to be added:</label>
            <input type="text" id="PName" name="PName" placeholder="Nut">
            <br>
            <label for="Color">Please enter desired color of the Part to be added:</label>
            <input type="text" id="Color" name="Color" placeholder="Red">
            <br>
            <label for="Weight">Please enter desired weight of the part to be added:</label>
            <input type="text" id="Weight" name="Weight" placeholder="12">
            <br>
            
            <input type="submit" value="Submit">
    </form>

<?php

$sql = "INSERT INTO Parts (Part, PName, Color, Weight) VALUES (?, ?, ?, ?)";

try
{
    $statement = $pdo->prepare($sql);
    $result = $statement->execute(array('Part', 'PName', 'Color', 'Weight'));
    if($result)
    {
        echo "Part Added Successfully";
    }
    else
    {
        echo "Part Failed to be added to Database";
    }


}
catch(PDOException $e)
{
    echo "Couldn't add a new Part. Query failed due to PDO Exception with message: " . $e->getMessage();
}

?>








</body>
</html>
